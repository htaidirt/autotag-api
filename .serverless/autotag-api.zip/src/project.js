(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 10);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("source-map-support/register");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/regenerator");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("uuid/v4");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.response = exports.dynamodb = exports.CONST = undefined;

var _const = __webpack_require__(5);

Object.defineProperty(exports, 'CONST', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_const).default;
  }
});

var _dynamodb = __webpack_require__(6);

Object.defineProperty(exports, 'dynamodb', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_dynamodb).default;
  }
});

var _response = __webpack_require__(8);

Object.defineProperty(exports, 'response', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_response).default;
  }
});

__webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

__webpack_require__(0);

var env = "production";

exports.default = {
  TABLES: {
    PROJECTS: "auto-tag-" + env + "-projects",
    RESOURCES: "auto-tag-" + env + "-resources",
    JOBS: "auto-tag-" + env + "-jobs"
  }
};

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

__webpack_require__(0);

var _awsSdk = __webpack_require__(7);

var _awsSdk2 = _interopRequireDefault(_awsSdk);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_awsSdk2.default.config.update({ region: 'eu-west-1' });

var documentClient = function documentClient() {
  return new _awsSdk2.default.DynamoDB.DocumentClient();
};

var call = function call(action, params) {
  return documentClient()[action](params).promise();
};

exports.default = {
  documentClient: documentClient,
  call: call
};

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(9);

var _stringify2 = _interopRequireDefault(_stringify);

__webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (body) {
  var statusCode = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 200;
  return {
    statusCode: statusCode,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': true
    },
    body: (0, _stringify2.default)(body)
  };
};

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.list = exports.get = exports.create = undefined;

var _regenerator = __webpack_require__(1);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(2);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var create = exports.create = function () {
  var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(event) {
    var data, params;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            data = JSON.parse(event.body);

            if (!(!data.title || !data.type)) {
              _context.next = 3;
              break;
            }

            return _context.abrupt('return', (0, _lib.response)({ status: false, error: 'Invalid project title or type' }, 500));

          case 3:
            params = {
              TableName: _lib.CONST.TABLES.PROJECTS,
              Item: {
                userId: event.requestContext.identity.cognitoIdentityId,
                projectId: (0, _v2.default)(),
                title: data.title,
                description: data.description,
                type: data.type,
                status: data.status || 'ACTIVE',
                createdAt: Date.now()
              }
            };
            _context.prev = 4;
            _context.next = 7;
            return _lib.dynamodb.call('put', params);

          case 7:
            return _context.abrupt('return', (0, _lib.response)(params.Item, 201));

          case 10:
            _context.prev = 10;
            _context.t0 = _context['catch'](4);
            return _context.abrupt('return', (0, _lib.response)({ status: false, error: _context.t0 }, 500));

          case 13:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[4, 10]]);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var get = exports.get = function () {
  var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(event) {
    var params, result;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            params = {
              TableName: _lib.CONST.TABLES.PROJECTS,
              Key: {
                userId: event.requestContext.identity.cognitoIdentityId,
                projectId: event.pathParameters.id
              }
            };
            _context2.prev = 1;
            _context2.next = 4;
            return _lib.dynamodb.call('get', params);

          case 4:
            result = _context2.sent;

            if (!result.Item) {
              _context2.next = 7;
              break;
            }

            return _context2.abrupt('return', (0, _lib.response)(result.Item, 200));

          case 7:
            return _context2.abrupt('return', (0, _lib.response)({ status: false, error: 'Project not found' }, 404));

          case 10:
            _context2.prev = 10;
            _context2.t0 = _context2['catch'](1);
            return _context2.abrupt('return', (0, _lib.response)({ status: false, error: _context2.t0 }, 500));

          case 13:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[1, 10]]);
  }));

  return function get(_x2) {
    return _ref2.apply(this, arguments);
  };
}();

var list = exports.list = function () {
  var _ref3 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(event) {
    var params, result;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            params = {
              TableName: _lib.CONST.TABLES.PROJECTS,
              KeyConditionExpression: 'userId = :userId',
              ExpressionAttributeValues: {
                ':userId': event.requestContext.identity.cognitoIdentityId
              }
            };
            _context3.prev = 1;
            _context3.next = 4;
            return _lib.dynamodb.call('query', params);

          case 4:
            result = _context3.sent;
            return _context3.abrupt('return', (0, _lib.response)(result.Items, 200));

          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3['catch'](1);
            return _context3.abrupt('return', (0, _lib.response)({ status: false, error: _context3.t0 }, 500));

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[1, 8]]);
  }));

  return function list(_x3) {
    return _ref3.apply(this, arguments);
  };
}();

__webpack_require__(0);

var _v = __webpack_require__(3);

var _v2 = _interopRequireDefault(_v);

var _lib = __webpack_require__(4);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ })
/******/ ])));
//# sourceMappingURL=project.js.map